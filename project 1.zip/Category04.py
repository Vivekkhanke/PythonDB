# Write a program to accept category like "romance" and display list of books of that category

#!F:\Python programming\python installed\python.exe
import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()

category=input("Enter Book category : ")
curs.execute("select bookname from books where category='%s'" % category)
data=curs.fetchall()

print("** List of all Books **")
for i in data:
    print(i[0])