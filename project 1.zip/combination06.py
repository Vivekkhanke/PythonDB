# Write a program to accept author and publication, display list of books of the author-publication combination

#!F:\Python programming\python installed\python.exe
import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()

curs.execute("select author,publication from books")
data=curs.fetchall()
for i in data:
    print("Author       : ",i[0])
    print("publication  : ",i[1])
    print()
con.close()
