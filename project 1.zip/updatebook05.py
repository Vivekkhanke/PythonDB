# Write a program to accept bookcode & new price and update book data in the table if found else display "book does not exist"

#!F:\Python programming\python installed\python.exe
import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()
try:
    bookcodes=input("Enter Book code : ")
    curs.execute("select * from books where bookcode='%s'" %bookcodes)
    data=curs.fetchone()
    if data:
        bookprice=int(input("Enter book price : "))
        curs.execute("update books set price=%d where bookcode='%s'"%(bookprice,bookcodes))
        con.commit()
        print('New book price updated')
    else: 
        print('Book does not exit')        
except:
    print('Error in updation..')