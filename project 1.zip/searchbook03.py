# Write a program to accept bookcode, search book in the table, show the book details if found else display "not found" message

#!F:\Python programming\python installed\python.exe
import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()
try:
    bookcodes=input("Enter Book code : ")
    curs.execute("select * from books where bookcode='%s'" %bookcodes)
    rec=curs.fetchone()

    if rec:
        print("Book Name        : '%s'" %rec[1])
        print("Book category    : '%s'" %rec[2])
        print("Book Author      : '%s'" %rec[3])
        print("Book Publication : '%s'" %rec[4])
        print("Book Edition     :  %d" %rec[5])
        print("Book Prics       :  %d" %rec[6])
    else:
        print("Data not found")
except:
    print("Please enter valid book code ")
con.close()