#!F:\Python programming\python installed\python.exe

import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()

print("*** List of books ***")
curs.execute("select bookname from books")

books=curs.fetchall()

for i in books:
    print(i)