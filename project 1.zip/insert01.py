#!F:\Python programming\python installed\python.exe

import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()

n=int(input("Enter the number of books : "))
for i in range(0,n):
    bookcode=input("Enter bookcode : ")
    booknm=input('Enter book name : ')
    category=input("Enter books category : ")
    auther=input('Enter auther name : ')
    pub=input('Enter publication : ')
    edition=int(input('Enter edition : '))
    price=int(input('Enter book price : '))
    curs.execute("insert into books values('%s','%s','%s','%s','%s',%d,%d)" %(bookcode,booknm,category,auther,pub,edition,price))
    print("Data insert successfully")
    con.commit()

con.close()

