# Write a program to accept bookcode and review, update the record with the review contents

#!F:\Python programming\python installed\python.exe
import mysql.connector as mycon

con=mycon.connect(host='bmssvrxlfgmumyrdxjqx-mysql.services.clever-cloud.com',user='udpmipulruc1ieox',password='aiutVph0kZ1rIL87YDnn',database='bmssvrxlfgmumyrdxjqx')
curs=con.cursor()

try:
    bookcode=input("Enter Book Code : ")
    curs.execute("select * from  books where  bookcode='%s'" %bookcode)
    data=curs.fetchall()
    if data:
        review=input("Update Your Review : ")
        curs.execute("update books set review='%s' where bookcode='%s'" %(review,bookcode))
        con.commit()
        print("Reviews Updated successfully ")
    else:
        print("Reviews Not Updated ")
except:
    print("Book code is not valid ")
con.close()

    


